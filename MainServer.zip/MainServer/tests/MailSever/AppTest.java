package MailSever;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AppTest {

    @Test
    void signin() {
        String id="mohamed";
        String pw="1234";
        App x=new App();
        x.signin(id,pw);
        assertTrue(x.signin(id,pw));
    }
}