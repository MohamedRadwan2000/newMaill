package MailSever;
import library.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;
import java.io.File;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        Scanner in=new Scanner(System.in);
        while (true){
        System.out.println("1-sign in. 2-sign up");
        String x=in.next();
        if(x.charAt(0)=='1') {
            System.out.println("Enter ID:");
            String email = in.next();
            System.out.println("Enter pw:");
            String pw = in.next();
            App y = new App();
            if (!y.signin(email, pw)) {
                System.out.println("Account not found");
            }
        }
            else if(x.charAt(0)=='2'){
                System.out.println("Enter ID:");
                String email1=in.next();
                System.out.println("Enter pw:");
                String pw1=in.next();
                IContact h= new IContact(email1,pw1);
            App y = new App();
                y.signup(h);
            }
        }

            }
        }


