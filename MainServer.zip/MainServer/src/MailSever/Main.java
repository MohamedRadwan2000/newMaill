package MailSever;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        GUI b=new GUI();
      
                    }
        }


