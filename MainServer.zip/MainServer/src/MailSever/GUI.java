package MailSever;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class GUI extends JFrame implements ActionListener {
    private JPanel p1,p2;
    private JButton signin=new JButton("SIGNIN");
    private JButton signup=new JButton("SIGNUP");
    private TextField t1;
    private TextField t2;
    private Label l1,l2;
    String s1 ;
    String s2 ;


    public GUI() {

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
        this.setSize(500,600);
        this.createUIComponents();
        this.setTitle("Radwan Mail Server ");

       p1= new JPanel();
       p2=new JPanel();
       t1=new TextField();
       t2=new TextField();
       l1=new Label();
       l2=new Label();
       l1.setText("ID:");
       l1.setFont(new Font("",Font.BOLD,22));
       l2.setText("Password:");
       l2.setFont(new Font("",Font.BOLD,22));
       p1.setBackground(Color.LIGHT_GRAY);
       p2.setBackground(Color.gray);
       this.setLayout(new GridLayout(2,1));
       this.add(p1);
       this.add(p2);
       signin.setBounds(40,100,100,40);
       signup.setBounds(350,100,100,40);
       t1.setBounds(168,30,150,20);
       t2.setBounds(168,70,150,20);
       l1.setBounds(135,30,150,20);
       l2.setBounds(55,70,150,20);
       p1.setLayout(null);
       p1.add(signin);
       p1.add(signup);
       p1.add(t1);
       p1.add(t2);
       p1.add(l1);
       p1.add(l2);
       signup.addActionListener(this);
       signin.addActionListener(this);
    }

    private void createUIComponents() {

        // TODO: place custom component creation code here
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signup) {
            try {
                s1 = t1.getText();
                s2 = t2.getText();
                IContact c1 = new IContact(s1, s2);
                App x = new App();
                if (!x.signup(c1)) {
                    //default title and icon
                    JOptionPane.showMessageDialog(signup,
                            "invalid name or password");
                }
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
        if (e.getSource() == signin) {
            s1 = t1.getText();
            s2 = t2.getText();
            App x=new App();
            if(x.signin(s1,s2)){this.setVisible(false);
            Signin gui2=new Signin();}
            else {
                //default title and icon
                JOptionPane.showMessageDialog(signup,
                        "invalid name or password");
            }
        }
    }

}
