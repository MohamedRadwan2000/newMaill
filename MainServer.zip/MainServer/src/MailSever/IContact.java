package MailSever;
import library.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class IContact {

       private String name=null;
       private String pw=null;
       public singlyLinkedList stk=new singlyLinkedList();
        public  IContact(String name1,String pw) throws IOException {
            if (name1.length() > 8) {
                String name = name1.substring(0, name1.length() - 8);
                String f = "@raa.com";
                name1 = name1.toLowerCase();
                name = name.toLowerCase();
                if ( name1.substring(name1.length() - 8, name1.length()).contains(f) && !((name.contains("!")) || (name.contains("/")) || (name.contains("%")) || (name.contains("$")) || (name.contains("-")) || (name.contains("=")) || (name.contains("^")) || (name.contains("#")) || (name.contains(",")) || (name.contains("{")) || (name.contains("}")) || (name.contains("(")) || (name.contains(")")) || (name.contains("*")) || (name.contains("~")) || (name.contains("<")) || (name.contains(">")) || (name.contains(":")) || (name.contains("@")))) {
                    if (pw.length() > 8&&!pw.contains(" ")) {
                        BufferedReader br = null;
                        int counter = 0;
                        br = new BufferedReader(new FileReader("data_base//accounts//ID.txt"));
                        for (int i = 0; br.readLine() != null; i++) {
                            counter++;
                        }
                        br = new BufferedReader(new FileReader("data_base//accounts//ID.txt"));
                        for (int i = 0; i < counter; i++) {
                            stk.add(i, br.readLine());
                        }
                        this.name = name1;
                        this.pw = pw;
                    }
                } else {
                    System.out.println("Invalid name");
                }
            }
        }
            public boolean exist(){
            for(int i=1;i<stk.size;i++){
                if(i%2==1){
                    if(name.equals((String) stk.get(i))){
                        if(pw.equals((String)stk.get(i+1))){
                        return true;}
                    }
                }
            }
            return false;
            }
    public boolean exist_signup(){
        for(int i=1;i<stk.size;i++){
            if(i%2==1){
                if(name.equals((String) stk.get(i))){
                   return true;
                }
            }
        }
        return false;
    }


    public singlyLinkedList getStk() {
        return stk;
    }

    public String getName() {
        return name;
    }

    public String getPw() {
        return pw;
    }

    // TODO Auto-generated constructor stub
        }


