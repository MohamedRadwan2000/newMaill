package MailSever;

import library.ILinkedList;

public interface IApp {
    boolean signIn(String email, String password);

    boolean signUp(IContact contact);

//    void setViewingOptions(IFolder folder, IFilter filter, ISort sort);

    IMail[] listEmails(int page);

    void deleteEmails(ILinkedList mails);

    boolean compose(IMail email);
}
