package MailSever;

import library.ILinkedList;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class IApp_Implementation implements IApp {
    @Override
    public boolean signIn(String email, String password) {
        try {
            IContact check=new IContact(email,password);
            if(check.exist()==true){return true;}
            else {return false;}
        } catch (IOException e) {
            e.printStackTrace();
        }

        return true;
    }

    @Override
    public boolean signUp(IContact contact) {
        if(!contact.exist()) {
            if (contact.getName() != null) {
                try (Writer writer = Files.newBufferedWriter(
                        Paths.get("data_base//accounts//ID.txt"), StandardCharsets.UTF_8,
                        StandardOpenOption.WRITE,
                        StandardOpenOption.APPEND)) {
                    writer.write(contact.getName() + "\n");
                    writer.write(contact.getPw() + "\n");} catch (IOException e) {
                    e.printStackTrace();
                }
                File file = new File("data_base//" + contact.getName());
                boolean bool = file.mkdir();
                if(bool){
                    System.out.println("Directory created successfully");
                }else{
                    System.out.println("Sorry couldn’t create specified directory");
                }

                File file1 = new File("data_base//" + contact.getName()+"//inbox");

                boolean bool1= file1.mkdir();
                if(bool1){
                    System.out.println("Directory created successfully");
                }else{
                    System.out.println("Sorry couldn’t create specified directory");
                }

                File file2 = new File("data_base//" + contact.getName()+"//sent");

                boolean bool2 = file2.mkdir();
                if(bool2){
                    System.out.println("Directory created successfully");
                }else{
                    System.out.println("Sorry couldn’t create specified directory");
                }
                File file3 = new File("data_base//" + contact.getName()+"//trash");

                boolean bool3 = file3.mkdir();
                if(bool3){
                    System.out.println("Directory created successfully");
                }else{
                    System.out.println("Sorry couldn’t create specified directory");
                }
                File file4 = new File("data_base//" + contact.getName()+"//drafts");

                boolean bool4 = file4.mkdir();
                if(bool4){
                    System.out.println("Directory created successfully");
                }else{
                    System.out.println("Sorry couldn’t create specified directory");
                }
                File file5 = new File("data_base//" + contact.getName()+"//contacts");

                boolean bool5 = file5.mkdir();
                if(bool5){
                    System.out.println("Directory created successfully");
                }else{
                    System.out.println("Sorry couldn’t create specified directory");
                }

            }
            return true;}
        else {return false;}
    }

    //@Override
  //  public void setViewingOptions(IFolder folder, IFilter filter, ISort sort) {

    //}

    @Override
    public IMail[] listEmails(int page) {
        return new IMail[0];
    }

    @Override
    public void deleteEmails(ILinkedList mails) {
        for (int i = 0; i < mails.size(); i++) {
            File dir = (File) mails.get(i);
            String[] entries = dir.list();
            if(entries != null) {
                for (String s : entries) {
                    File currentFile = new File(dir.getPath(), s);
                    currentFile.delete();
                }
            }
            dir.delete();
        }
    }

  //  @Override
    //public void moveEmails(ILinkedList mails, IFolder des) {

    //}

    @Override
    public boolean compose(IMail email) {
        return false;
    }
}
