package MailSever;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

public class App {
public boolean signin(String email,String pw) {
    try {
        IContact check=new IContact(email,pw);
        if(check.exist()==true){return true;}
        else {return false;}
    } catch (IOException e) {
        e.printStackTrace();
    }

   return true;
}
    public boolean signup(IContact contact) {
    if(!contact.exist_signup()) {
        if (contact.getName() != null) {
            try (Writer writer = Files.newBufferedWriter(
                    Paths.get("data_base//accounts//ID.txt"), StandardCharsets.UTF_8,
                    StandardOpenOption.WRITE,
                    StandardOpenOption.APPEND)) {
                writer.write(contact.getName() + "\n");
                writer.write(contact.getPw() + "\n");} catch (IOException e) {
                e.printStackTrace();
            }
            File file = new File("data_base//" + contact.getName());
            boolean bool = file.mkdir(); 
            if(bool){
                System.out.println("Directory created successfully");
            }else{
                System.out.println("Sorry couldn’t create specified directory");
            }

            File file1 = new File("data_base//" + contact.getName()+"//inbox");

            boolean bool1= file1.mkdir();
            if(bool1){
                System.out.println("Directory created successfully");
            }else{
                System.out.println("Sorry couldn’t create specified directory");
            }

            File file2 = new File("data_base//" + contact.getName()+"//sent");

            boolean bool2 = file2.mkdir();
            if(bool2){
                System.out.println("Directory created successfully");
            }else{
                System.out.println("Sorry couldn’t create specified directory");
            }
            File file3 = new File("data_base//" + contact.getName()+"//trash");

            boolean bool3 = file3.mkdir();
            if(bool3){
                System.out.println("Directory created successfully");
            }else{
                System.out.println("Sorry couldn’t create specified directory");
            }
            File file4 = new File("data_base//" + contact.getName()+"//drafts");

            boolean bool4 = file4.mkdir();
            if(bool4){
                System.out.println("Directory created successfully");
            }else{
                System.out.println("Sorry couldn’t create specified directory");
            }
            File file5 = new File("data_base//" + contact.getName()+"//contacts");

            boolean bool5 = file5.mkdir();
            if(bool5){
                System.out.println("Directory created successfully");
            }else{
                System.out.println("Sorry couldn’t create specified directory");
            }


            return true;
        }

    return false;}
        else {return false;}
}
}
