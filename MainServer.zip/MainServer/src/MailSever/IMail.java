package MailSever;
import library.singlyLinkedList;
import library.queueLinkedListImplementation;

import java.awt.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class IMail {
    public String Subject;
    public String Body = "";
    public singlyLinkedList Attachments = new singlyLinkedList();
    public singlyLinkedList Urls = new singlyLinkedList();
    public int Count = 0;
    public IContact Sender = new IContact("mohamed@raa.com","123456789");
    public queueLinkedListImplementation receivers = new queueLinkedListImplementation();
    public IMail() throws IOException {
    }




    public void readBody() throws IOException {
        String line = "";
        Scanner input = new Scanner(System.in);
        do{
            line = input.nextLine();
            Body += line + "\n";
        } while (!line.equals("^C"));
    }




    public void readAttachments() throws IOException {
        String line = "";
        Scanner input = new Scanner(System.in);
        do{
            line = input.nextLine();
            File file = new File(line);
            Attachments.add(file);
        } while (!line.equals("^D"));
        Attachments.remove(Attachments.size-1);
    }




    public void readUrls(){
        Scanner input = new Scanner(System.in);
        String line = input.nextLine();
        URL link = null;
        boolean flag = false;
        while (!flag) {
            try {
                link = new URL(line);
                flag = true;
            } catch (MalformedURLException e) {
                System.out.println("Invalid link");
                line = input.nextLine();
            }
        }
        Urls.add(link);
    }






    public void deleteAttachmentAt(int i){Attachments.remove(i);}
    public void reset(){
        Subject = null;
        Body = null;
        Attachments.clear();
        Urls.clear();
    }






    public void sendMail() throws IOException {
        if(receivers.isEmpty())   throw new RuntimeException();
        singlyLinkedList SL = new singlyLinkedList();
        String path = "";
        while (!receivers.isEmpty()){
            String  receiver = (String) receivers.dequeue();
            SL.add(receiver);
            path = "data_base//" + receiver + "//inbox//Email_"+ Count + "//";
            File email = new File(path);
            email.mkdir();
            File message = new File(path + "Content.txt");
            message.createNewFile();
            BufferedWriter q = new BufferedWriter(new FileWriter(message));
            q.write("A New Email from " + Sender.getName());
            q.newLine();
            q.write(Subject);
            q.newLine();
            int j = 0 , k = 0;
            while (j < Body.length()-3){
                if(Body.charAt(j)=='\n'){
                    q.write(Body.substring(k,j));
                    q.newLine();
                    k = j;
                }
                j++;
            }
            if(!Urls.isEmpty()){
                for (int i = 0; i < Urls.size; i++) {
                    q.write((String) Urls.get(i));
                    q.newLine();
                }
            }
            q.close();
            for (int i = 0; i < Attachments.size; i++) {
                File newFile = (File)Attachments.get(i);
                Files.copy(newFile.toPath(),new File(path + newFile.getName()).toPath(),StandardCopyOption.REPLACE_EXISTING);
            }
        }
        String newPath = "data_base//" + Sender.getName() + "//sent//Email" + Count + "//";
        File savedEmail = new File(newPath);
        savedEmail.mkdir();
        File lastReceiver = new File(path);
        String[] entries = lastReceiver.list();
        for (String s : entries){
            File oldFile = new File(path + s);
            Files.copy(oldFile.toPath(),new File(newPath + oldFile.getName()).toPath());
        }
        String h = "You Have sent This Email to : ";
        for (int i = 0; i < SL.size-1; i++) {
            h += (String)SL.get(i) + " , ";
        }
        h += SL.get(SL.size-1);
        String g = "A New Email from " + Sender.getName();
        BufferedReader reader = new BufferedReader(new FileReader(new File(newPath + "Content.txt")));
        String Content = "";
        String line = reader.readLine();
        while (line != null){
            Content += line + System.lineSeparator();
            line = reader.readLine();
        }
        BufferedWriter writer = new BufferedWriter(new FileWriter(new File(newPath + "Content.txt")));
        writer.write(Content.replaceAll(g,h));
        reader.close();
        writer.close();
        Count++;
    }
}

